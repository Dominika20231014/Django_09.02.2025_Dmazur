from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib import messages
from .models import Car, Reservation
from .forms import UserRegistrationForm  # Używamy własnego formularza rejestracji
from django.contrib.auth.decorators import login_required
from datetime import datetime

# Widok pokazujący listę dostępnych samochodów
def car_list(request):
    cars = Car.objects.filter(available=True).order_by('brand', 'model')
    
    # Filtrujemy po marce, jeśli użytkownik poda coś w formularzu
    brand = request.GET.get('brand')
    if brand:
        cars = cars.filter(brand__icontains=brand)
    
    return render(request, 'rental/car_list.html', {'cars': cars})

# Widok pokazujący szczegóły samochodu i możliwość rezerwacji
@login_required(login_url='login')  # Dodajemy parametr login_url
def car_detail(request, car_id):
    car = get_object_or_404(Car, id=car_id)
    today = datetime.today().date()

    success_message = None
    reservation_history = None

    if request.method == "POST":
        if 'reserve_button' in request.POST:
            start_date = request.POST.get('start_date')
            end_date = request.POST.get('end_date')

            # Przekształcamy daty
            try:
                start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
                end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
            except ValueError:
                messages.error(request, 'Proszę podać poprawne daty.')
                return redirect('car_detail', car_id=car.id)

            # Sprawdzamy poprawność dat
            if start_date < today:
                messages.error(request, 'Data rozpoczęcia rezerwacji nie może być wcześniejsza niż dzisiaj.')
            elif end_date < start_date:
                messages.error(request, 'Data zakończenia rezerwacji nie może być wcześniejsza niż data rozpoczęcia.')
            elif Reservation.objects.filter(car=car, start_date__lte=end_date, end_date__gte=start_date).exists():
                messages.error(request, 'Ten samochód jest już zarezerwowany w tym terminie.')
            else:
                # Tworzymy rezerwację
                reservation = Reservation.objects.create(car=car, user=request.user, start_date=start_date, end_date=end_date)
                car.available = False
                car.save()

                success_message = 'Rezerwacja została pomyślnie dokonana!'
                return redirect('reservation_success', reservation_id=reservation.id)

        elif 'history_button' in request.POST:
            reservation_history = Reservation.objects.filter(user=request.user).order_by('-start_date')

    return render(request, 'rental/car_detail.html', {
        'car': car,
        'today': today,
        'success_message': success_message,
        'reservation_history': reservation_history,
    })

# Funkcja rejestracji użytkownika (z formularzem niestandardowym)
def register(request):
    if request.user.is_authenticated:
        return redirect('car_list')

    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Konto zostało utworzone! Możesz się zalogować.')
            return redirect('login')  # Po rejestracji przekierowujemy do strony logowania
    else:
        form = UserRegistrationForm()

    return render(request, 'rental/register.html', {'form': form})

# Funkcja logowania użytkownika
def user_login(request):
    if request.user.is_authenticated:
        return redirect('car_list')

    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('car_list')
    else:
        form = AuthenticationForm()
    return render(request, 'rental/login.html', {'form': form})

# Funkcja wylogowania użytkownika
def user_logout(request):
    logout(request)
    return redirect('car_list')

# Widok potwierdzenia rezerwacji
@login_required
def reservation_success(request, reservation_id):
    reservation = get_object_or_404(Reservation, id=reservation_id)
    return render(request, 'rental/reservation_success.html', {'reservation': reservation})

# Funkcja anulowania rezerwacji
@login_required
def cancel_reservation(request, reservation_id):
    reservation = get_object_or_404(Reservation, id=reservation_id)
    
    # Anulowanie rezerwacji
    reservation.delete()
    
    messages.info(request, 'Rezerwacja została anulowana. Samochód pozostaje dostępny do wynajęcia.')
    return redirect('car_list')