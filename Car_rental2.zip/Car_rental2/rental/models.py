from django.db import models
from django.contrib.auth.models import User  # To pozwala na używanie użytkowników w projekcie
from django.core.exceptions import ValidationError  # Do obsługi walidacji

# Model samochodu
class Car(models.Model):
    brand = models.CharField(max_length=100)  # Marka samochodu
    model = models.CharField(max_length=100)  # Model samochodu
    year = models.PositiveIntegerField()  # Rok produkcji samochodu
    available = models.BooleanField(default=True)  # Czy samochód jest dostępny?
    description = models.TextField()  # Opis samochodu

    def __str__(self):
        return f"{self.brand} {self.model} ({self.year})"

# Model rezerwacji
class Reservation(models.Model):
    car = models.ForeignKey(Car, on_delete=models.CASCADE)  # Samochód, który jest rezerwowany
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Użytkownik, który rezerwuje
    start_date = models.DateField()  # Data rozpoczęcia rezerwacji
    end_date = models.DateField()  # Data zakończenia rezerwacji
    status = models.CharField(max_length=20, default="Pending")  # Status rezerwacji, np. oczekująca

    def __str__(self):
        return f"Reservation for {self.car} by {self.user} from {self.start_date} to {self.end_date}"

    def clean(self):
        if self.end_date < self.start_date:
            return "Data zakończenia rezerwacji nie może być wcześniejsza niż data rozpoczęcia."
        return None