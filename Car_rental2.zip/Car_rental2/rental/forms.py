from django import forms
from django.contrib.auth.models import User
from .models import Reservation

class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = ['start_date', 'end_date']

# NOWY FORMULARZ REJESTRACJI
class UserRegistrationForm(forms.ModelForm):
    password1 = forms.CharField(
        widget=forms.PasswordInput(),
        label="Hasło",
        min_length=8,
        help_text="Hasło musi zawierać przynajmniej 8 znaków."
    )
    password2 = forms.CharField(
        widget=forms.PasswordInput(),
        label="Powtórz hasło"
    )
    email = forms.EmailField(
        required=True, 
        label="Adres e-mail"
    )

    class Meta:
        model = User
        fields = ['username', 'email']  # Dodano email do formularza

    def clean_password2(self):
        """
        Sprawdzamy, czy oba hasła są identyczne i spełniają minimalne wymagania.
        """
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")
        
        # Sprawdzamy, czy hasła są identyczne
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Hasła muszą być identyczne.")
        
        # Dodajemy walidację długości hasła
        if len(password1) < 8:
            raise forms.ValidationError("Hasło musi zawierać przynajmniej 8 znaków.")
        
        return password2

    def save(self, commit=True):
        """
        Przypisujemy hasło użytkownikowi i zapisujemy nowego użytkownika.
        """
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])  # Ustawiamy hasło użytkownika
        if commit:
            user.save()
        return user

    def clean_email(self):
        """
        Sprawdzamy, czy podany adres e-mail już istnieje w bazie.
        """
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("Ten adres e-mail jest już zajęty.")
        return email