from django.urls import path
from . import views

urlpatterns = [
    path('', views.car_list, name='car_list'),
    path('car/<int:car_id>/', views.car_detail, name='car_detail'),
    path('car/cancel/<int:reservation_id>/', views.cancel_reservation, name='cancel_reservation'),
    path('reservation/success/<int:reservation_id>/', views.reservation_success, name='reservation_success'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='user_logout'),
]